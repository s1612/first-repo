package com.rentvideo.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class VideoController {
    // Define endpoints here
}
