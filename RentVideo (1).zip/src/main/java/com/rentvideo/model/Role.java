package com.rentvideo.model;

public enum Role {
    CUSTOMER, ADMIN
}