package com.rentvideo.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Video {
    @Id @GeneratedValue
    private Long id;
    private String title;
    private String director;
    private String genre;
    private boolean available = true;

    @OneToMany(mappedBy = "video", cascade = CascadeType.ALL)
    private List<Rental> rentals;
}